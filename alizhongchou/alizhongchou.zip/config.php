<?php
// HTTP
define('HTTP_SERVER', 'http://127.0.0.1:83/');
define('HTTP_CATALOG', 'http://127.0.0.1:83/');
define('HTTP_Aliyoyo','http://127.0.0.1/');

// HTTPS
define('HTTPS_SERVER', 'https://127.0.0.1:83/');
define('HTTPS_CATALOG', 'http://127.0.0.1:83/');
define('HTTPS_Aliyoyo','http://127.0.0.1/');

// DIR
define('DIR_APPLICATION', 'E:/aliyoyoPhp/alizhongchou/catalog/');
define('DIR_SYSTEM', 'E:/aliyoyoPhp/alizhongchou/system/');
define('DIR_IMAGE', 'E:/aliyoyoPhp/aliyoyo_com/image/');
define('DIR_S3IMAGE', 'http://image.aliyoyo.com/image/');
define('DIR_LANGUAGE', 'E:/aliyoyoPhp/alizhongchou/catalog/language/');
define('DIR_TEMPLATE', 'E:/aliyoyoPhp/alizhongchou/catalog/view/template/');
define('DIR_CONFIG', 'E:/aliyoyoPhp/alizhongchou/system/config/');
define('DIR_CACHE', 'E:/aliyoyoPhp/alizhongchou/system/storage/cache/');
define('DIR_DOWNLOAD', 'E:/aliyoyoPhp/alizhongchou/system/storage/download/');
define('DIR_LOGS', 'E:/aliyoyoPhp/alizhongchou/system/storage/logs/');
define('DIR_MODIFICATION', 'E:/aliyoyoPhp/alizhongchou/system/storage/modification/');
define('DIR_UPLOAD', 'E:/aliyoyoPhp/alizhongchou/system/storage/upload/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', '127.0.0.1');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '0626');
define('DB_DATABASE', 'aliyoyo_com');
define('DB_PORT', '3306');
define('DB_PREFIX', 'cf_');
define('DB_SHARE_PREFIX', 'oc_');
