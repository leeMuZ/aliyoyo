<?php 
$_emoticons["smile"] 	 = array(":-)");
$_emoticons["laughting"] = array(":-D");
$_emoticons["kiss"]  	= array(":-*");
$_emoticons["plain"] 	= array(":-|");
$_emoticons["kissing"]  = array(":kissing:");
$_emoticons["sad"] 		= array(":(", ":-(");
$_emoticons["blush"]  	= array(":blush:");
$_emoticons["surprise"] = array(":o", ":-o");
$_emoticons["devil"]  	= array(">:)", ">:D");
$_emoticons["wink"] 	= array(";)", ";-)");
$_emoticons["angel"] 	= array("o:)", "o:-)");
$_emoticons["dude"] 	= array("8)", "8-)");
$_emoticons["beer"] 	= array(":beer:");
$_emoticons["razz"]  	= array(":p", ":-p");
$_emoticons["silence"]  = array(":x", ":-x");
$_emoticons["stop"]  	= array(":stop:");
$_emoticons["inlove"]   = array(":inlove:");
$_emoticons["happy"]    = array(":happy:");
$_emoticons["rude"] 	= array(":\\");
$_emoticons["cry"]  	= array(":'(");
$_emoticons["bored"] 	= array(":bored:");
$_emoticons["thumbsup"] = array(":thumbsup:");
$_emoticons["angry"] 	= array(":angry:");
$_emoticons["kissed"] 	= array(":kissed:");
?>