<?php


namespace ImageOptimizer\Exception;

class CommandNotFound extends Exception
{
}