<?php


namespace ImageOptimizer\Exception;

class Exception extends \RuntimeException
{
}